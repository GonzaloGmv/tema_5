class Saludo:
    def __init__(self, nombre):
        self.nombre = nombre

    def saludar(self):
        print('Hola', self.nombre)