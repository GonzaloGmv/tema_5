from setuptools import setup

setup(
    name='paquete',
    version='0.1',
    packages=['paquete.hola', 'paquete.adios'],
    description='Paquete de prueba',
    author='Gonzalo'
)